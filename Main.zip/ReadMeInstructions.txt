Instructions for Mathematica Demonstration Files

Put the following files in a Directory:

Step 1:
CleanStart.wl
DeleteDuplicatesv20.0.wl
PolynomialPruningAddingv10.1.wl
FastDerivativesv5.1.wl
CGS.m
( These files are in MAIN.zip)

Step2:
In either another or the same directory, put 
TemplatesAndExamplesV1.2.nb
( Thhis file is also in MAIN.zip )
Step3:
Then make a sub-directory called Data.  In the sub-directory,
put all the things in the MathematicaDemo/Data  sub-directory
( These files are in Data1.zip and Data2.zip )

Step4:
In the data sub-directory that you made, make a sub-sub-directory
called "results" and in it place all the files that are in the 
MathematicaDemo/Data/Results directory 
( These files are in Results.zip )

Step5:
Then go to all templates saved in the first step.  Each template will have 
at the top  starting, for example,
<< "c:/PLHProjects/MathematicaDemo/CleanStart.wl";
Change the names to conform with the directory that you have made in
in Step 1.  They will also have lines such as, for example,
fortranname = 
  "C:/PLHProjects/MathematicaDemo/Data/\
             DuplicatesDeletedbemsaGLY1frag2221111_4ChenDOrd4.f90";
or such as
DataDir = "C:/PLHProjects/MathematicaDemo/Data/"; 
Change these names and any others that have "C:/PLHProjects/...." to 
conform witth the directories that you have made in Steps 1 and 3.



These "result" files are what should be produced by the templates,
except that the names produced will not have "result" at the end 
and they will be stored in the "data" directory.  

The templates describe how to do most of the procedures listed in: 

PESPIP: Software to fit complex molecular and many-body potential 
energy surfaces with permutationally invariant polynomials

P. L. Houston, C. Qu, Q. Yu, R. Conte, A. Nandi, J. K. Li, et al.

The Journal of Chemical Physics 2023 Vol. 158 Issue 4 Pages 044109

DOI: 10.1063/5.0134442
